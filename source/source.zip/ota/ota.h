
#ifndef _OTA_H_
#define _OTA_H_

void OTA_start(void);

#endif // _OTA_H_
