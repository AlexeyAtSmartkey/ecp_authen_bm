
#ifndef _LED_BLINKY_H_
#define _LED_BLINKY_H_

void LED_BLINKY_init(void);

#endif // _LED_BLINKY_H_
