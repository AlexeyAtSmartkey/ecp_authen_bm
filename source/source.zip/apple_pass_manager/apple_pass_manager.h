
#ifndef _APPLE_PASS_MANAGER_
#define _APPLE_PASS_MANAGER_

phStatus_t APPLE_PASS_read(void *pDataParams, phacDiscLoop_Sw_DataParams_t *discLoop);

#endif // _APPLE_PASS_MANAGER_
