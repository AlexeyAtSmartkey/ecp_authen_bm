
#ifndef _DELAY_MS_H_
#define _DELAY_MS_H_

void delay_ms(uint32_t ms);

#endif // _DELAY_MS_H_
