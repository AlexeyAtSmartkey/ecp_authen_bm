
#ifndef _SMARTLOCK_H_
#define _SMARTLOCK_H_

// Fixed size of data to be written to PICC
#define NFC_WRITE_DATA_SIZE						0x0024

// Affiliated buffer sizes
#define PROTOCOL_MSG_LENGTH_MAX					64

// Uncomment to turn on led blinking
// #define LED_BLINK

#endif // _SMARTLOK_H_
