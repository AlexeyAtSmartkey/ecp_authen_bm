
#ifndef _TASKMANAGER_PERIPH_H_
#define _TASKMANAGER_PERIPH_H_

void TASK_MANAGER_PERIPH_config(void);

void TASK_MANAGER_PERIPH_deinit(void);

#endif
